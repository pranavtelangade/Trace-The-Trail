from flask import Blueprint
bp = Blueprint('view', __name__, url_prefix='/face_detection')